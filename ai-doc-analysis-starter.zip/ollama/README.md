# Ollama Setup

This module will run local quantized LLMs. Configuration files will be added here.
