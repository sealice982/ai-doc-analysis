# AI Document Analysis Project

This project is modular and designed for local deployment using Docker. It includes Weaviate, Ollama, LlamaIndex, and a Streamlit GUI.
