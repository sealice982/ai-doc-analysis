# LlamaIndex Setup

Handles document ingestion, chunking, embedding, and vector storage.
