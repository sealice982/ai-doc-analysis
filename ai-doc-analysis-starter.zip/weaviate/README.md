# Weaviate Setup

This module sets up the Weaviate vector database. Run `docker-compose up` inside this directory to start Weaviate.
